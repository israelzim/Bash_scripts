# Bash_Script
examples of bash script syntax
