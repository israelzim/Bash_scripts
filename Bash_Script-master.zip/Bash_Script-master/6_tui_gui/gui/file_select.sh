

zenity --file-selection --separator=";"
