

whiptail --title "Example Dialog" --msgbox "This is an example of a message box. You must hit OK to continue." 8 78
