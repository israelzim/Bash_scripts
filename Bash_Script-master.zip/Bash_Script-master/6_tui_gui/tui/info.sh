

whiptail --title "Example Dialog" --infobox "This is an example of an info box." 8 78
