#!/usr.bin/env bash

unset Fruits[2]                         # Remove one item from array
