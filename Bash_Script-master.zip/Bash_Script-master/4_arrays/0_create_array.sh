#!/usr/bin/env bsh

#declaring array
echo '
Fruits=( "apple" "banana" "orange")
'

Fruits=( "apple" "banana" "orange")

echo "declaring  array in different way:"

echo "Fruits[0]='apple'
	  Fruits[1]='banana'
	  Fruits[2]='orange'"

Fruits[0]='apple'
Fruits[1]='banana'
Fruits[2]='orange'
