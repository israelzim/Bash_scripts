#!/usr/bin/env bash 

#################################################################
#Created by : Alex
#Date	    : When ever
#Purpose    : general functions
################################################################

#Variables ++++++++++++++++++++++++++++++++++++++++++++++++++++

ARCH=$(uname -m)
DISTRO=`lsb_release -si`
KODENAME=`lsb_release -sc`


#Funcstions ::::::::::::::::::::::::::::::::::::::::::::::::::::

cl(){
clear
}

sys_data(){



}

