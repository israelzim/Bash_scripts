#!/usr/bin/env bash

 for counter in {1..20}
    do
	echo  counting  from 1 to 20 , now at  $counter
	    sleep 1
    done  
