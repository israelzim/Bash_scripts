#!/usr/bin/env

for counter in  `seq 1 20`
    do  
        echo  counting  from 1 to 20 , now at  $counter
            sleep 1
    done  
