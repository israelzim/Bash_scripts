#!/bin/bash

set -x #enbaling internal debugging

var=42 #setting variable

echo "the answer is $var"
