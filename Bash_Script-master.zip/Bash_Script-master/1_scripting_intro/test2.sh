#!/bin/bash

var="42"

echo $var

