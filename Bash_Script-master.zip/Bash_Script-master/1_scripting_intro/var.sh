#!/bin/bash

VAR=100 # choosing variable


echo "VAR=$VAR"
