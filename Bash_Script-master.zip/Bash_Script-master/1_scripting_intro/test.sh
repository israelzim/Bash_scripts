ls 
pwd
cd /tmp
touch $HOME/this_is_my_file
rm $HOME/this_is_my_file`
echo done
