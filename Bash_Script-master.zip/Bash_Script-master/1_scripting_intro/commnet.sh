#!/bin/bash
# this is comment

<< comment 
multi line 
comment

: '
another way to multi-line comment
'
echo "this script includes comments"
