#!/usr/bin/env bash 

# what about $0
: '
$0 is pointer to the 
name of the
'
echo this script is called $0

