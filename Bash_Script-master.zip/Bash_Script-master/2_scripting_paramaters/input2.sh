#!/usr/bin/env

read -p "Please enter you age" AGE
 echo -e "you are $AGE y/o"
