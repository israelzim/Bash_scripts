#!/usr/bin/env

NAME=""

echo -e "Please enter you name:\n"
read NAME
echo -e "Hello $NAME\n"
